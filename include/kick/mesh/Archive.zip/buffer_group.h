//
//  buffer_group.h
//  KickCPP
//
//  Created by Morten Nobel-Jørgensen on 12/11/13.
//  Copyright (c) 2013 Morten Nobel-Joergensen. All rights reserved.
//

#pragma once

#include <iostream>
#include <string>
#include <memory>
#include <vector>
#include "kick/core/kickgl.h"
#include "kick/core/project_asset.h"


namespace kick {
    class Buffer;
    
    // Buffer groups is a collection of buffers
    class BufferGroup : public ProjectAsset {
    public:
        BufferGroup(const char* data, int64_t length);
        BufferGroup(std::shared_ptr<GLubyte*> data, int64_t dataLength, std::string name = "");
        void setName(std::string name){ this->name = name; }
        std::string getName(){ return name; }
        GLubyte* getData() { return *data.get(); }
        void addBuffer(Buffer* buffer);
        void removeBuffer(Buffer* buffer);
    private:
        std::shared_ptr<GLubyte*> data;
        int64_t dataLength;
        std::string name;
        std::vector<std::unique_ptr<Buffer>> buffers;
    };
}