//
//  Buffer.h
//  KickCPP
//
//  Created by Morten Nobel-Jørgensen on 02/11/13.
//  Copyright (c) 2013 Morten Nobel-Joergensen. All rights reserved.
//

#pragma once

#include <string>
#include <memory>
#include "kick/core/project_asset.h"
#include "kick/core/kickgl.h"

namespace kick {
    enum class BufferType {
        Array = GL_ARRAY_BUFFER,
        CopyRead = GL_COPY_READ_BUFFER,
        CopyWrite = GL_COPY_WRITE_BUFFER,
        ElementArray = GL_ELEMENT_ARRAY_BUFFER,
        PixelPack = GL_PIXEL_PACK_BUFFER,
        PixelUnpack = GL_PIXEL_UNPACK_BUFFER,
        Texture = GL_TEXTURE_BUFFER,
        TransformFeedback = GL_TRANSFORM_FEEDBACK_BUFFER,
        Uniform = GL_UNIFORM_BUFFER,
#ifdef KICK_OGL_430
        AtomicCounter = GL_ATOMIC_COUNTER_BUFFER,
        DrawIndirect = GL_DRAW_INDIRECT_BUFFER,
        DispatchIndirect = GL_DISPATCH_INDIRECT_BUFFER,
        QueryBuffer = GL_QUERY_BUFFER,
        ShaderStorage = GL_SHADER_STORAGE_BUFFER,
#endif
    };
    
    BufferType toBufferType(std::string name);
    
    
    enum class BufferUsage {
        /** The user will be writing data to the buffer, but the user will not read it. */
        Draw = 0,
        /** The user will not be writing data, but the user will be reading it back. */
        Read = 1,
        /** The user will be neither writing nor reading the data. */
        Copy = 2
    };
    
    enum class BufferUpdateType {
        /** The user will be changing the data after every use. Or almost every use. */
        Stream = GL_STREAM_DRAW,
        /** The user will set the data once. */
        Static = GL_STATIC_DRAW,
        /** The user will set the data occasionally. */
        Dynamic = GL_DYNAMIC_DRAW,
        
    };
    
    class BufferGroup;
    
    /**
     * A Buffer object correspond to an OpenGL buffer object, which store unformatted memory allocated by the OpenGL context.
     */
    class Buffer : public ProjectAsset {
    public:
        Buffer() = delete;
        Buffer(BufferGroup* bufferGroup, int64_t offset, int64_t length, BufferType bufferType, BufferUpdateType bufferUpdateType = BufferUpdateType::Static, BufferUsage bufferUsage = BufferUsage::Draw);
        Buffer(const char* data, int64_t length, BufferType bufferType, BufferUpdateType bufferUpdateType = BufferUpdateType::Static, BufferUsage bufferUsage = BufferUsage::Draw);
        Buffer(const Buffer&) = delete;
        ~Buffer();
        void bind();
        void setName(std::string name) { this->name = name; }
        std::string getName(){ return name; }
    private:
        BufferGroup * bufferGroup = nullptr;
        GLuint bufferid;
        int64_t offset = 0;
        int64_t length = 0;
        kick::BufferType bufferType;
        std::string name;
    };
    
    

}