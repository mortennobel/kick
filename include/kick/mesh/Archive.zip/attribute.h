//
//  attribute.h
//  KickCPP
//
//  Created by Morten Nobel-Jørgensen on 12/11/13.
//  Copyright (c) 2013 Morten Nobel-Joergensen. All rights reserved.
//

#pragma once

#include <iostream>
#include <vector>
#include "kick/core/kickgl.h"

namespace kick {
    class Buffer;
    
    enum class AttributeType {
        Byte = GL_BYTE,
        UByte = GL_UNSIGNED_BYTE,
        Short = GL_SHORT,
        UShort = GL_UNSIGNED_SHORT,
        Int = GL_INT,
        UInt = GL_UNSIGNED_INT,
        HalfFloat = GL_HALF_FLOAT,
        Float = GL_FLOAT,
#ifdef KICK_OGL_410        
        Double = GL_DOUBLE,
        Fixed = GL_FIXED,
        Int_2_10_10_10 = GL_INT_2_10_10_10_REV,
#endif
        UInt_2_10_10_10 = GL_UNSIGNED_INT_2_10_10_10_REV,
        UInt_10_11_11 = GL_UNSIGNED_INT_10F_11F_11F_REV,
    };
    
    class Attribute {
    public:
        Attribute(Buffer* buffer, size_t byteOffset, GLsizei byteStride, GLint size, int count, bool normalized, AttributeType attributeType, std::vector<float> &max, std::vector<float> &min);
        Buffer* getBuffer() { return buffer; }
        const std::vector<float> &getMin(){ return min; }
        const std::vector<float> &getMax(){ return max; }
        int getSize(){ return size; }
        int getCount() { return count; }
        bool getNormalized() { return normalized; }
        AttributeType getAttributeType(){ return attributeType; }
        void vertexAttribPointer(GLuint index);
    private:
        Buffer* buffer;
        size_t byteOffset;
        GLsizei byteStride;
        GLint size;
        int count;
        bool normalized;
        AttributeType attributeType;
        std::vector<float> max;
        std::vector<float> min;

    };
}
